package com.example.jizdnirady;

import org.mapsforge.map.android.layers.MyLocationOverlay;

public class GetMyLocation{

}
